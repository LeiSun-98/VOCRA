clc;
clear all;
close all;

% to be adjusted:

outlier_ratio=0.9; %(0.01 to 0.99)

% fixed:

n_ele=1000;

noise=0.01;

show_figure=0;

scale_gt=1;

[pts_3d,pts_3d_,R_gt,t_gt]=Build_Scenario(n_ele,noise,outlier_ratio,scale_gt,show_figure);

tic;

pair_n_ele=0.5*n_ele*(n_ele-1);
s=zeros(1,pair_n_ele);a=zeros(1,pair_n_ele);count=0;re_=6*noise;w=zeros(1,n_ele);u=1.5;
enough=0;max_vote=0.2*n_ele;

pick=randperm(n_ele);

for i=1:n_ele
    for j=i+1:n_ele
        count=count+1;
        a1=norm(pts_3d(pick(i),:)-pts_3d(pick(j),:));
        a2=norm(pts_3d_(pick(i),:)-pts_3d_(pick(j),:));
        re1=(a1-a2)^2;

% Tukey
    if re1>u*re_^2
    weight=0;
    elseif re1<=u*re_^2
    weight=(1-re1/(u*re_^2))^2;
    end
    
    w(pick(i))=w(pick(i))+weight;w(pick(j))=w(pick(j))+weight;

    
    end
    
    if i<=20
    if w(pick(i))>=max_vote
        enough=1;
        break
    end
    end
    
end


[~,w2]=sort(w,'descend');


best_set=[];

if enough==0

n_ele_=round(0.2*n_ele);

elseif enough==1
    
n_ele_=n_ele;
    
end

bound=5;

yes=0;

R_raw=eye(3,3);

best_is=0;

res=zeros(1,n_ele_);res_bp=zeros(1,1);
for i=1:n_ele_-2
    point1=w2(i);
    for j=i+1:n_ele_-1
        point2=w2(j);
        base=norm(pts_3d(point1,:)-pts_3d(point2,:));
        if abs(norm(pts_3d_(point1,:)-pts_3d_(point2,:))/base-1)<=bound*noise/base
        R_this=cell(1);ca=0;cp=0;num_this=zeros(1,1);k=j;N=n_ele_;
        while k<N %for k=j+1:n_ele
            k=k+1;
            point3=w2(k);

            base1=norm(pts_3d(point1,:)-pts_3d(point3,:));
            base2=norm(pts_3d(point3,:)-pts_3d(point2,:));
           if abs(norm(pts_3d_(point1,:)-pts_3d_(point3,:))/base1-1)<=bound*noise/base1 && ...
               abs(norm(pts_3d_(point3,:)-pts_3d_(point2,:))/base2-1)<=bound*noise/base2
               
               v12=pts_3d(point1,:)-pts_3d(point3,:);
               X_axis=v12'/norm(v12);
               v13=pts_3d(point2,:)-pts_3d(point3,:);
               v23=cross(v12,v13);
               Y_axis=v23'/norm(v23);
               Z_axis=cross(X_axis,Y_axis);

               v12=pts_3d_(point1,:)-pts_3d_(point3,:);
               X_axis_=v12'/norm(v12);
               v13=pts_3d_(point2,:)-pts_3d_(point3,:);
               v23=cross(v12,v13);
               Y_axis_=v23'/norm(v23);
               Z_axis_=cross(X_axis_,Y_axis_);
    
               R_this_temp=[X_axis_,Y_axis_,Z_axis_]*[X_axis,Y_axis,Z_axis]';
               
               ca=ca+1;
                                  
               R_this{ca}=R_this_temp;
               num_this(ca)=point3;

               if ca>=round(0.01*n_ele)-2
                   
               b_outlier_rejection = true;
               n_iterations = 10;
               thr_convergence = 0.001;
               R_raw = ChordalL1Mean(R_this, b_outlier_rejection, n_iterations, thr_convergence);
               R_raw=double(R_raw);
               
               is=0;point_=zeros(1,1);
               for check_rot_in=1:ca
                   if norm(R_raw(:)-R_this{check_rot_in}(:))<=0.14
                   is=is+1;
                   point_(is)=num_this(check_rot_in);
                   end
               end
               
               if is>=best_is
                   best_is=is;
                   best_set=unique([point1,point2,point3,point_]);
                   if enough==0
                   if best_is>=round(n_ele*0.01)+1
                    yes=1;
                    break
                   end
                   else
                   if best_is>=round(n_ele*0.01)+6
                    yes=1;
                    break
                   end
                   end
               end
               
               end
                          
           end
        end
        
        if yes==1
            break
        end
        
        end
    end
    
    if yes==1
        break
    end
    
end


best_size=length(best_set);
u=100;re_=5*noise;sum_res=0;
w=ones(1,best_size);
re=zeros(1,best_size);

for itr_GNC=1:50

q_=zeros(3,1);
p_=zeros(3,1);

for i=1:best_size

q_(1)=q_(1)+w(i)*pts_3d_(best_set(i),1);
q_(2)=q_(2)+w(i)*pts_3d_(best_set(i),2);
q_(3)=q_(3)+w(i)*pts_3d_(best_set(i),3);

p_(1)=p_(1)+w(i)*pts_3d(best_set(i),1);
p_(2)=p_(2)+w(i)*pts_3d(best_set(i),2);
p_(3)=p_(3)+w(i)*pts_3d(best_set(i),3);

end

p_=p_/sum(w);
q_=q_/sum(w);

H=zeros(3,3);
for i=1:best_size
    H=H+w(i)*(pts_3d(best_set(i),:)'-p_)*(pts_3d_(best_set(i),:)'-q_)';
end

[U,~,V]=svd(H);

R_opt=V*U';

t_opt=q_-R_opt*p_;

for i=1:best_size

re(i)=(R_opt*pts_3d(best_set(i),:)'+t_opt-pts_3d_(best_set(i),:)')'*(R_opt*pts_3d(best_set(i),:)'+t_opt-pts_3d_(best_set(i),:)');
if re(i)>u*re_^2
    w(i)=0;
elseif re(i)<=u*re_^2
    w(i)=(1-re(i)/(u*re_^2))^2;
end   

end

u=u/1.2;

if abs(sum_res-sum(re))<=1e-10 || u<1
   break 
end

sum_res=sum(re);

end

inlier_set=zeros(1,1);in_count=0;

for i=1:n_ele
    if norm(R_opt*pts_3d(i,:)'+t_opt-pts_3d_(i,:)')<=bound*noise
        in_count=in_count+1;
        inlier_set(in_count)=i;
    end
end

in_size=length(inlier_set);

q_=zeros(3,1);
p_=zeros(3,1);

for i=1:in_size

q_(1)=q_(1)+pts_3d_(inlier_set(i),1);
q_(2)=q_(2)+pts_3d_(inlier_set(i),2);
q_(3)=q_(3)+pts_3d_(inlier_set(i),3);

p_(1)=p_(1)+pts_3d(inlier_set(i),1);
p_(2)=p_(2)+pts_3d(inlier_set(i),2);
p_(3)=p_(3)+pts_3d(inlier_set(i),3);

end

p_=p_/in_size;
q_=q_/in_size;

H=zeros(3,3);
for i=1:in_size
    H=H+(pts_3d(inlier_set(i),:)'-p_)*(pts_3d_(inlier_set(i),:)'-q_)';
end

[U,~,V]=svd(H);

R_opt=V*U';

t_opt=q_-R_opt*p_;

time=toc();

R_error=getAngularError(R_opt,R_gt)*180/pi;

t_error=norm(t_opt-t_gt');

recall=length(best_set)/((1-outlier_ratio)*n_ele);

fprintf(['Rotation Error:']);

R_error

fprintf(['Translation Error:']);

t_error

fprintf(['Runtime:']);

time


%% Function definitions (adopted from paper: 'Robust Single Rotation Averaging' by Lee, S.H. and Civera, J)

function out = logarithm_map(in)
    cos_theta = (trace(in)-1)/2;
    sin_theta = sqrt(1-cos_theta^2);
    theta = acos(cos_theta);
    ln_R = theta/(2*sin_theta)*(in-in');
    out = [ln_R(3,2);ln_R(1,3);ln_R(2,1)];
end


function out = SkewSymmetricMatrix(in)
    out=[0 -in(3) in(2) ; in(3) 0 -in(1) ; -in(2) in(1) 0 ];
end


function R = RotationFromUnitAxisAngle(unit_axis, angle)
    
    if (angle==0)
        R = eye(3);
    else
        so3 = SkewSymmetricMatrix(unit_axis);
        R = eye(3)+so3*sin(angle)+so3^2*(1-cos(angle));
    end
end

function R = ProjectOntoSO3(M)   
    [U,~,V] = svd(M);
    R = U*V.';
    if (det(R) < 0)
        V(:,3) = -V(:,3);
        R = U*V.';
    end
end


function R = ChordalL1Mean(R_input, b_outlier_rejection, n_iterations, thr_convergence)
    
    % 1. Initialize
    n_samples = length(R_input);
    
    vectors_total = zeros(9,n_samples);
    for i = 1:n_samples
        vectors_total(:,i)= R_input{i}(:);
    end      

    s = median(vectors_total,2);
                
    % 2. Optimize
    for j = 1:n_iterations
        if (sum(sum(abs(vectors_total-s))==0) ~= 0)
            s = s+rand(size(s,1),1)*0.001;
        end

        v_norms = zeros(1,n_samples);
        for i = 1:n_samples
            v =  vectors_total(:,i)-s;
            v_norm = norm(v);
            v_norms(i) = v_norm;
        end

        % Compute the inlier threshold (if we reject outliers).
        thr = inf;
        if (b_outlier_rejection)
            sorted_v_norms = sort(v_norms);
            v_norm_firstQ = sorted_v_norms(ceil(n_samples/4));

            if (n_samples <= 50)
                thr = max(v_norm_firstQ, 1.356);
                % 2*sqrt(2)*sin(1/2) is approximately 1.356
            else
                thr = max(v_norm_firstQ, 0.7);
                % 2*sqrt(2)*sin(0.5/2) is approximately 0.7
            end
        end

        step_num = 0;
        step_den = 0;
        for i = 1:n_samples
            v_norm = v_norms(i);
            if (v_norm > thr)
                continue;
            end
            step_num = step_num + vectors_total(:,i)/v_norm;
            step_den = step_den + 1/v_norm;
        end


        s_prev = s;
        s = step_num/step_den;

        update_medvec = s-s_prev;
        if (norm(update_medvec) < thr_convergence)
            break;
        end
    
    
    end
    
    R = ProjectOntoSO3(reshape(s, [3 3]));


end
